package com.example.exp_5



import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var editTextName: EditText
    private lateinit var editTextCGPA: EditText
    private lateinit var buttonSave: Button

    private val STORAGE_PERMISSION_CODE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextName = findViewById(R.id.editTextName)
        editTextCGPA = findViewById(R.id.editTextCGPA)
        buttonSave = findViewById(R.id.buttonSave)

        buttonSave.setOnClickListener {
            if (checkPermission()) {
                saveDataToSDCard()
            } else {
                requestPermission()
            }
        }
    }

    private fun checkPermission(): Boolean {
        val permission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
        return permission == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
            STORAGE_PERMISSION_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveDataToSDCard()
            } else {
                Toast.makeText(this, "Permission denied!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveDataToSDCard() {
        val name = editTextName.text.toString()
        val cgpa = editTextCGPA.text.toString()

        if (name.isEmpty() || cgpa.isEmpty()) {
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val state = Environment.getExternalStorageState()
        if (Environment.MEDIA_MOUNTED != state) {
            Toast.makeText(this, "SD Card not found!", Toast.LENGTH_SHORT).show()
            return
        }

        val file = File(Environment.getExternalStorageDirectory(), "student_info.txt")

        try {
            val fos = FileOutputStream(file, true) // true for append mode
            fos.write("Name: $name, CGPA: $cgpa\n".toByteArray())
            fos.close()
            Toast.makeText(this, "Saved Successfully!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error Saving!", Toast.LENGTH_SHORT).show()
        }
    }
}
